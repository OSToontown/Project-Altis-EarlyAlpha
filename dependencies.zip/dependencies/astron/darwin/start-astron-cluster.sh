#!/bin/sh
cd ..
./astrond --loglevel info config/cluster.yml
