#!/bin/sh
cd ..
./astrond --loglevel info config/prod-test.yml
